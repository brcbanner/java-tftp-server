"""
TFTP Server Test Script (RFC 1350)

Tests:
  1. RRQ retransmission: client does not send ACK → server retransmits
  2. RRQ wrong block number: client ACKs with wrong block# (99)
  3. RRQ wrong block off-by-one: client ACKs with block 0 instead of 1
  4. WRQ retransmission: client does not send DATA → server retransmits ACK

Configure SERVER_ADDR, SERVER_PORT, READ_FILENAME, and WRITE_FILENAME below.
"""
# This line is needed for Python 3.7-3.9 to allow the "list[tuple[...]]" type annotation syntax.
from __future__ import annotations

import socket
import struct
import sys
import time

# ═══════════════════════════════════════════════════════════════
#  USER CONFIGURATION — edit these before running
# ═══════════════════════════════════════════════════════════════

SERVER_ADDR    = "127.0.0.1"
SERVER_PORT    = 4096               # server listening port

READ_FILENAME  = "2kb.png"          # file that EXISTS in server's READDIR
WRITE_FILENAME = "test_upload.txt"  # file to create in server's WRITEDIR
                                    # (must NOT already exist, server rejects duplicates)

BUFSIZE        = 516
TIMEOUT        = 10                 # overall receive timeout per test (seconds)

# ═══════════════════════════════════════════════════════════════

# ── TFTP constants & helpers ──────────────────────────────────

OP_RRQ = 1
OP_WRQ = 2
OP_DAT = 3
OP_ACK = 4
OP_ERR = 5


def build_rrq(filename: str, mode: str = "octet") -> bytes:
    return struct.pack("!H", OP_RRQ) + filename.encode() + b"\x00" + mode.encode() + b"\x00"


def build_wrq(filename: str, mode: str = "octet") -> bytes:
    return struct.pack("!H", OP_WRQ) + filename.encode() + b"\x00" + mode.encode() + b"\x00"


def build_ack(block: int) -> bytes:
    return struct.pack("!HH", OP_ACK, block)


def build_data(block: int, payload: bytes) -> bytes:
    return struct.pack("!HH", OP_DAT, block) + payload


def parse_packet(data: bytes):
    """Returns (opcode, block_or_errcode, payload_or_errmsg)."""
    opcode = struct.unpack("!H", data[:2])[0]
    if opcode == OP_DAT:
        block = struct.unpack("!H", data[2:4])[0]
        return opcode, block, data[4:]
    elif opcode == OP_ACK:
        block = struct.unpack("!H", data[2:4])[0]
        return opcode, block, b""
    elif opcode == OP_ERR:
        errcode = struct.unpack("!H", data[2:4])[0]
        errmsg = data[4:].rstrip(b"\x00").decode("ascii", errors="replace")
        return opcode, errcode, errmsg
    else:
        return opcode, 0, data[2:]


def pretty(opcode, block_or_err, payload):
    names = {OP_RRQ: "RRQ", OP_WRQ: "WRQ", OP_DAT: "DATA", OP_ACK: "ACK", OP_ERR: "ERR"}
    name = names.get(opcode, f"OP({opcode})")
    if opcode == OP_DAT:
        return f"{name} block={block_or_err} len={len(payload)}"
    elif opcode == OP_ACK:
        return f"{name} block={block_or_err}"
    elif opcode == OP_ERR:
        return f"{name} code={block_or_err} msg=\"{payload}\""
    return f"{name} raw={payload!r}"


# ── Server connectivity check ─────────────────────────────────

def check_server_reachable() -> bool:
    """
    Send a small RRQ probe to the server and wait briefly for any response.
    Returns True if the server replies (DATA or ERROR), False on timeout.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(3)
    try:
        sock.sendto(build_rrq(READ_FILENAME), (SERVER_ADDR, SERVER_PORT))
        data, _ = sock.recvfrom(BUFSIZE)
        return True
    except socket.timeout:
        return False
    finally:
        sock.close()


# ── Result tracker ────────────────────────────────────────────

results: list[tuple[str, bool, str]] = []


def record(name: str, passed: bool, detail: str = ""):
    results.append((name, passed, detail))
    mark = "PASS ✓" if passed else "FAIL ✗"
    print(f"  [{mark}] {detail}")


# ═══════════════════════════════════════════════════════════════
#  TEST 1 — RRQ: No ACK → server retransmits DATA then gives up
# ═══════════════════════════════════════════════════════════════

def test_rrq_no_ack_retransmission():
    name = "RRQ no-ACK retransmission"
    print("=" * 60)
    print(f"TEST 1: {name}")
    print("  → Send RRQ, never ACK. Expect server retransmits DATA #1.")
    print("=" * 60)

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(TIMEOUT)

    try:
        sock.sendto(build_rrq(READ_FILENAME), (SERVER_ADDR, SERVER_PORT))
        print(f"[→] Sent RRQ for \"{READ_FILENAME}\"")

        received = []
        while True:
            try:
                data, addr = sock.recvfrom(BUFSIZE)
                pkt = parse_packet(data)
                received.append(pkt)
                print(f"[←] {pretty(*pkt)}   from {addr}")
            except socket.timeout:
                print("[*] Socket timed out (no more packets)")
                break

        data1 = [p for p in received if p[0] == OP_DAT and p[1] == 1]
        errs  = [p for p in received if p[0] == OP_ERR]

        print()
        passed_retransmit = len(data1) > 1
        record(name, passed_retransmit,
               f"Server retransmitted DATA#1 ×{len(data1)}"
               if passed_retransmit else
               f"Server sent DATA#1 only {len(data1)} time(s) — expected >1")

        if errs:
            record(name + " (error sent)", True,
                   f"Server sent ERROR after giving up: code={errs[-1][1]} \"{errs[-1][2]}\"")
        else:
            record(name + " (error sent)", False,
                   "Server did not send an explicit ERROR packet after retries")

        print(f"  Total packets: {len(received)}\n")
    finally:
        sock.close()


# ═══════════════════════════════════════════════════════════════
#  TEST 2 — RRQ: Wrong block number in ACK (block 99)
# ═══════════════════════════════════════════════════════════════

def test_rrq_wrong_block_number():
    name = "RRQ wrong ACK block# (99)"
    print("=" * 60)
    print(f"TEST 2: {name}")
    print("  → Send RRQ, get DATA#1, ACK with block 99.")
    print("=" * 60)

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(TIMEOUT)

    try:
        sock.sendto(build_rrq(READ_FILENAME), (SERVER_ADDR, SERVER_PORT))
        print(f"[→] Sent RRQ for \"{READ_FILENAME}\"")

        received = []
        server_addr = None
        wrong_sent = False

        while True:
            try:
                data, addr = sock.recvfrom(BUFSIZE)
                if server_addr is None:
                    server_addr = addr
                pkt = parse_packet(data)
                received.append(pkt)
                print(f"[←] {pretty(*pkt)}   from {addr}")

                if pkt[0] == OP_DAT and pkt[1] == 1 and not wrong_sent:
                    sock.sendto(build_ack(99), server_addr)
                    print("[→] Sent ACK with WRONG block# 99")
                    wrong_sent = True
                elif pkt[0] == OP_ERR:
                    break
            except socket.timeout:
                print("[*] Socket timed out")
                break

        data1 = [p for p in received if p[0] == OP_DAT and p[1] == 1]
        data2 = [p for p in received if p[0] == OP_DAT and p[1] == 2]

        print()
        no_advance = len(data2) == 0
        record(name, no_advance,
               "Server did NOT advance to block 2 (correct)"
               if no_advance else
               "Server incorrectly advanced to block 2 despite wrong ACK")

        if len(data1) > 1:
            record(name + " (retransmit)", True,
                   f"Server retransmitted DATA#1 ×{len(data1)} after wrong ACK")
        print(f"  Total packets: {len(received)}\n")
    finally:
        sock.close()


# ═══════════════════════════════════════════════════════════════
#  TEST 3 — RRQ: Wrong block number off-by-one (ACK #0)
# ═══════════════════════════════════════════════════════════════

def test_rrq_wrong_block_off_by_one():
    name = "RRQ wrong ACK block# (0, off-by-one)"
    print("=" * 60)
    print(f"TEST 3: {name}")
    print("  → Send RRQ, get DATA#1, ACK with block 0.")
    print("=" * 60)

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(TIMEOUT)

    try:
        sock.sendto(build_rrq(READ_FILENAME), (SERVER_ADDR, SERVER_PORT))
        print(f"[→] Sent RRQ for \"{READ_FILENAME}\"")

        received = []
        server_addr = None
        wrong_sent = False

        while True:
            try:
                data, addr = sock.recvfrom(BUFSIZE)
                if server_addr is None:
                    server_addr = addr
                pkt = parse_packet(data)
                received.append(pkt)
                print(f"[←] {pretty(*pkt)}   from {addr}")

                if pkt[0] == OP_DAT and pkt[1] == 1 and not wrong_sent:
                    sock.sendto(build_ack(0), server_addr)
                    print("[→] Sent ACK with WRONG block# 0 (expected 1)")
                    wrong_sent = True
                elif pkt[0] == OP_ERR:
                    break
            except socket.timeout:
                print("[*] Socket timed out")
                break

        data1 = [p for p in received if p[0] == OP_DAT and p[1] == 1]
        data2 = [p for p in received if p[0] == OP_DAT and p[1] == 2]

        print()
        no_advance = len(data2) == 0
        record(name, no_advance,
               "Server did NOT advance to block 2 (correct)"
               if no_advance else
               "Server incorrectly advanced to block 2 despite wrong ACK")

        if len(data1) > 1:
            record(name + " (retransmit)", True,
                   f"Server retransmitted DATA#1 ×{len(data1)} after wrong ACK(0)")
        print(f"  Total packets: {len(received)}\n")
    finally:
        sock.close()


# ═══════════════════════════════════════════════════════════════
#  TEST 4 — WRQ: No DATA sent → server retransmits ACK#0
# ═══════════════════════════════════════════════════════════════

def test_wrq_no_data_retransmission():
    """
    Send a WRQ. Server should reply with ACK#0.
    We never send DATA block 1, so the server should retransmit ACK#0
    multiple times then give up (send ERROR or stop).
    """
    name = "WRQ no-DATA retransmission"
    print("=" * 60)
    print(f"TEST 4: {name}")
    print("  → Send WRQ, never send DATA. Expect server retransmits ACK#0.")
    print("=" * 60)

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(TIMEOUT)

    try:
        sock.sendto(build_wrq(WRITE_FILENAME), (SERVER_ADDR, SERVER_PORT))
        print(f"[→] Sent WRQ for \"{WRITE_FILENAME}\"")

        received = []
        while True:
            try:
                data, addr = sock.recvfrom(BUFSIZE)
                pkt = parse_packet(data)
                received.append(pkt)
                print(f"[←] {pretty(*pkt)}   from {addr}")
                # Do NOT send DATA — that's the point
            except socket.timeout:
                print("[*] Socket timed out (no more packets)")
                break

        ack0 = [p for p in received if p[0] == OP_ACK and p[1] == 0]
        errs = [p for p in received if p[0] == OP_ERR]

        print()
        # Check for file-exists error (server rejects if file already there)
        if errs and any(e[1] == 6 for e in errs):
            record(name, False,
                   f"Server rejected WRQ — file \"{WRITE_FILENAME}\" already exists. "
                   "Delete it from WRITEDIR and re-run.")
            print(f"  Total packets: {len(received)}\n")
            return

        passed_retransmit = len(ack0) > 1
        record(name, passed_retransmit,
               f"Server retransmitted ACK#0 ×{len(ack0)}"
               if passed_retransmit else
               f"Server sent ACK#0 only {len(ack0)} time(s) — expected >1")

        if errs:
            record(name + " (error sent)", True,
                   f"Server sent ERROR after giving up: code={errs[-1][1]} \"{errs[-1][2]}\"")
        else:
            record(name + " (error sent)", False,
                   "Server did not send an explicit ERROR packet after retries")

        print(f"  Total packets: {len(received)}\n")
    finally:
        sock.close()


# ═══════════════════════════════════════════════════════════════
#  SUMMARY
# ═══════════════════════════════════════════════════════════════

def print_summary():
    print()
    print("=" * 60)
    print("  TEST SUMMARY")
    print("=" * 60)
    passed = 0
    failed = 0
    for test_name, ok, detail in results:
        mark = "PASS ✓" if ok else "FAIL ✗"
        print(f"  [{mark}]  {test_name}")
        if not ok:
            print(f"           → {detail}")
        if ok:
            passed += 1
        else:
            failed += 1
    print("-" * 60)
    print(f"  Total: {passed + failed}  |  Passed: {passed}  |  Failed: {failed}")
    if failed == 0:
        print("  All tests passed! ✓")
    else:
        print(f"  {failed} test(s) failed. ✗")
    print("=" * 60)
    print()


# ── Main ──────────────────────────────────────────────────────

if __name__ == "__main__":
    if len(sys.argv) >= 2:
        SERVER_PORT = int(sys.argv[1])
    if len(sys.argv) >= 3:
        READ_FILENAME = sys.argv[2]
    if len(sys.argv) >= 4:
        WRITE_FILENAME = sys.argv[3]

    print(f"Server:         {SERVER_ADDR}:{SERVER_PORT}")
    print(f"Read file:      {READ_FILENAME}  (must exist in server READDIR)")
    print(f"Write file:     {WRITE_FILENAME}  (will be created in server WRITEDIR)")
    print()

    print("Checking server connectivity... ", end="", flush=True)
    if not check_server_reachable():
        print("FAILED")
        print(f"\n  ERROR: No response from {SERVER_ADDR}:{SERVER_PORT}.")
        print("  Make sure the TFTP server is running before executing tests.")
        sys.exit(1)
    print("OK")
    print()

    test_rrq_no_ack_retransmission()
    time.sleep(1)

    test_rrq_wrong_block_number()
    time.sleep(1)

    test_rrq_wrong_block_off_by_one()
    time.sleep(1)

    test_wrq_no_data_retransmission()

    print_summary()

    # Exit with non-zero if any test failed
    sys.exit(0 if all(ok for _, ok, _ in results) else 1)