Instructions for running the TFTP retransmission & wrong-block-number tests
============================================================================

Prerequisites
-------------
- Python 3.10+
- The TFTP server source (TFTPServer.java) compiled and ready to run.

Server configuration
--------------------
1. Set the server's timeout limit to 5 seconds and retry limit to 3.
2. Place "2kb.png" into the server's read directory (e.g. public/read/).
3. Make sure "test_upload.txt" does NOT already exist in the server's
   write directory (e.g. public/write/). The server rejects duplicate files,
   and Test 4 (WRQ retransmission) will fail if the file is already there.

Starting the server
-------------------
Compile and start the server, for example:

    javac TFTPServer.java
    java TFTPServer 4096 public/read/ public/write/

Note the address (normally 127.0.0.1) and port (the script defaults to 4096).

Running the tests
-----------------
Simply run:

    python3 test_tftp.py

The script first performs a connectivity check — if the server is not
reachable it will print an error and exit immediately instead of waiting
through long timeouts.

Optional command-line arguments (in order):

    python3 test_tftp.py [PORT] [READ_FILE] [WRITE_FILE]

You can also edit the configuration variables at the top of test_tftp.py:

    SERVER_ADDR    = "127.0.0.1"
    SERVER_PORT    = 4096
    READ_FILENAME  = "2kb.png"
    WRITE_FILENAME = "test_upload.txt"

What the tests cover
--------------------
Test 1 — RRQ no-ACK retransmission
    Sends RRQ, never ACKs. Expects the server to retransmit DATA #1
    multiple times, then give up with an ERROR packet.

Test 2 — RRQ wrong ACK block# (99)
    Sends RRQ, receives DATA #1, replies with ACK block 99.
    Expects the server NOT to advance to block 2.

Test 3 — RRQ wrong ACK block# (0, off-by-one)
    Sends RRQ, receives DATA #1, replies with ACK block 0.
    Expects the server NOT to advance to block 2.

Test 4 — WRQ no-DATA retransmission
    Sends WRQ, never sends DATA. Expects the server to retransmit ACK #0
    multiple times, then give up with an ERROR packet.
